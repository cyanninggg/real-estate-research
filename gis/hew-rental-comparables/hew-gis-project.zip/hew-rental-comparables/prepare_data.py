#!/usr/bin/env python3
"""Download official source layers and prepare WGS84 property points; no QGIS output claimed."""
from pathlib import Path
from datetime import datetime, timezone
import csv, hashlib, json, urllib.request, urllib.parse
ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent / 'real-estate-research'
RAW = ROOT / 'raw'
DATA = ROOT / 'data'
RAW.mkdir(exist_ok=True)
DATA.mkdir(exist_ok=True)
BOSTON = 'https://gis.bostonplans.org/hosting/rest/services/Hosted/Boston_Neighborhood_Boundaries/FeatureServer/5'
MASSGIS = 'https://arcgisserver.digital.mass.gov/arcgisserver/rest/services/AGOL/MBTA_Rapid_Transit/MapServer'
records = []
def retrieve(url, target, **extra):
    request = urllib.request.Request(url, headers={'User-Agent':'CyanLiResearch-GIS-SourcePreparation/1.0'})
    data = urllib.request.urlopen(request, timeout=60).read()
    parsed = json.loads(data)
    if 'error' in parsed: raise RuntimeError(parsed['error'])
    target.write_bytes(data)
    records.append(dict(file=str(target.relative_to(ROOT)), url=url, retrieved_utc=datetime.now(timezone.utc).isoformat(), sha256=hashlib.sha256(data).hexdigest(), **extra))
    return parsed
for name, endpoint in [('boston_neighborhoods', BOSTON), ('massgis_rapid_transit_stations', MASSGIS+'/3'), ('massgis_rapid_transit_lines', MASSGIS+'/4')]:
    metadata=retrieve(endpoint+'?f=pjson', RAW/(name+'_metadata.json'))
    params=dict(where='1=1',outFields='*',returnGeometry='true',outSR='4326',f='geojson')
    count=retrieve(endpoint+'/query?'+urllib.parse.urlencode(dict(where='1=1',returnCountOnly='true',f='json')),RAW/(name+'_count.json'))['count']
    features=retrieve(endpoint+'/query?'+urllib.parse.urlencode(params),DATA/(name+'.geojson'), source_crs=metadata.get('extent',{}).get('spatialReference'),output_crs='OGC:CRS84 / EPSG:4326 (longitude, latitude)',selection='All features, no geographic clipping')
    if features.get('type')!='FeatureCollection' or len(features['features'])!=count: raise RuntimeError('Incomplete feature retrieval: '+name)
    print(name, count, 'features; count verified')
register_path=REPO/'data/hew-comparables-map.json'
if not register_path.exists(): register_path=ROOT/'property_source_register.json'
register=json.loads(register_path.read_text())
features=[]
for i,p in enumerate(register['properties']):
    lat,lon=p['coordinates']
    assert -180<=lon<=180 and -90<=lat<=90
    props=dict(property_id=['hew','harper','alder'][i], name=p['name'], address=p['address'],role=p['role'],source='U.S. Census address geocoder' if i<2 else 'Named property place linked from official Alder website',source_url='https://geocoding.geo.census.gov/geocoder/' if i<2 else 'https://maps.app.goo.gl/YEQpbjmF7fcBPNKMA',verified=register['verified'],accuracy_note='Approximate address/property point; not a surveyed entrance')
    if i<2:
        url='https://geocoding.geo.census.gov/geocoder/locations/onelineaddress?'+urllib.parse.urlencode(dict(address=p['address'],benchmark='Public_AR_Current',format='json'))
        geocode=retrieve(url,RAW/(props['property_id']+'_geocode.json'))
        matches=geocode.get('result',{}).get('addressMatches',[])
        assert matches, 'Address no longer matches: '+p['name']
        c=matches[0]['coordinates']
        # Compare stored coordinate provenance, without silently substituting a fresh point.
        props['current_geocode_lon']=c['x'];props['current_geocode_lat']=c['y']
        props['source_coordinate_match']=abs(c['x']-lon)<0.000001 and abs(c['y']-lat)<0.000001
    features.append(dict(type='Feature',id=props['property_id'],properties=props,geometry=dict(type='Point',coordinates=[lon,lat])))
(DATA/'properties.geojson').write_text(json.dumps(dict(type='FeatureCollection',features=features),indent=2)+'\n')
(RAW/'existing_property_source_register.json').write_text(json.dumps(register,indent=2)+'\n')
with (DATA/'properties.csv').open('w',newline='') as out:
    fields=['property_id','name','address','role','longitude','latitude','source_url','accuracy_note']
    writer=csv.DictWriter(out,fieldnames=fields);writer.writeheader()
    for f in features:
        row={k:f['properties'].get(k,'') for k in fields};row.update(longitude=f['geometry']['coordinates'][0],latitude=f['geometry']['coordinates'][1]);writer.writerow(row)
for path in sorted(DATA.glob('*.geojson')):
    obj=json.loads(path.read_text()); assert obj['type']=='FeatureCollection'
    def positions(geom):
        if geom['type']=='GeometryCollection':
            for g in geom['geometries']:yield from positions(g)
        else:
            def walk(c):
                if isinstance(c,list) and len(c)>=2 and all(isinstance(n,(int,float)) for n in c[:2]):yield c
                else:
                    for v in c:yield from walk(v)
            yield from walk(geom['coordinates'])
    count=0
    for feature in obj['features']:
        assert feature.get('geometry'), 'Null geometry: '+str(path)
        for xy in positions(feature['geometry']):
            assert -180<=xy[0]<=180 and -90<=xy[1]<=90, 'Invalid WGS84 coordinate'
            count+=1
    print(path.name,len(obj['features']),'features;',count,'coordinate pairs range-checked')
(ROOT/'source_manifest.json').write_text(json.dumps(dict(prepared_utc=datetime.now(timezone.utc).isoformat(),status='Source preparation for the documented QGIS workflow',sources=records),indent=2)+'\n')
