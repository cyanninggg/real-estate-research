"""Retrieve official historical road context and MassGIS water, not a web basemap."""
from pathlib import Path
import json,urllib.request,urllib.parse,hashlib,datetime,zipfile
root=Path(__file__).resolve().parent
(root/'raw').mkdir(exist_ok=True);(root/'data').mkdir(exist_ok=True)
url='https://www2.census.gov/geo/tiger/TIGER2020/ROADS/tl_2020_25025_roads.zip'
raw=urllib.request.urlopen(url,timeout=90).read();archive=root/'raw/suffolk_county_roads_2020.zip';archive.write_bytes(raw)
folder=root/'data/census_roads_2020';folder.mkdir(exist_ok=True)
with zipfile.ZipFile(archive) as z:
 for entry in z.infolist():
  assert Path(entry.filename).name==entry.filename,'Unexpected archive path'
  z.extract(entry,folder)
records=[{'url':url,'sha256':hashlib.sha256(raw).hexdigest(),'selection':'Suffolk County 2020 roads; clipped in QGIS, historical context only'}]
p=json.loads((root/'data/properties.geojson').read_text())['features'];xy=[f['geometry']['coordinates'] for f in p]
bbox=[min(v[0] for v in xy)-.025,min(v[1] for v in xy)-.015,max(v[0] for v in xy)+.025,max(v[1] for v in xy)+.015]
endpoint='https://arcgisserver.digital.mass.gov/arcgisserver/rest/services/AGOL/Hydro_Major/MapServer/2'
params={'where':'1=1','geometry':','.join(map(str,bbox)),'geometryType':'esriGeometryEnvelope','inSR':4326,'spatialRel':'esriSpatialRelIntersects','outFields':'*','returnGeometry':'true','outSR':4326,'f':'geojson'}
url=endpoint+'/query?'+urllib.parse.urlencode(params);raw=urllib.request.urlopen(url,timeout=60).read();d=json.loads(raw)
assert d['type']=='FeatureCollection' and all(f['geometry']['type'] in ['Polygon','MultiPolygon'] for f in d['features'])
(root/'data/water_context.geojson').write_bytes(raw);(root/'raw/water_context_response.json').write_bytes(raw)
records.append({'url':url,'sha256':hashlib.sha256(raw).hexdigest(),'selection':'Cartographic envelope, not an accessibility catchment'})
(root/'context_sources.json').write_text(json.dumps({'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'requests':records},indent=2)+'\n')
